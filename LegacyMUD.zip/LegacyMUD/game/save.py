# save.py

"""
save.py — Handles basic persistence for LocalMUD.

This module saves and loads game state to the local 'save/' directory.
Currently it supports serializing the Player object to JSON using the
player's own to_dict() and load_from_dict() methods. The structure is
designed to expand later to include world state, NPCs, flags, and other
persistent systems.
"""


import os
import json

SAVE_DIR = "save"
PLAYER_FILE = "player.json"
WORLD_FILE = "world.json"




def save_player(player):
    """Serialize the Player object using its to_dict() method."""
    os.makedirs(SAVE_DIR, exist_ok=True)

    save_path = os.path.join(SAVE_DIR, PLAYER_FILE)
    with open(save_path, "w", encoding="utf-8") as f:
        json.dump(player.to_dict(), f, indent=2)


def load_player(player):
    """Load player.json and apply it to the existing Player instance."""
    try:
        with open(os.path.join(SAVE_DIR, PLAYER_FILE), "r", encoding="utf-8") as f:
            data = json.load(f)
            player.load_from_dict(data)
            return True
    except FileNotFoundError:
        return False

def save_world(world):
    os.makedirs(SAVE_DIR, exist_ok=True)
    save_path = os.path.join(SAVE_DIR, WORLD_FILE)
    with open(save_path, "w", encoding="utf-8") as f:
        json.dump(world.to_dict(), f, indent=2)


def load_world(world):
    try:
        with open(os.path.join(SAVE_DIR, WORLD_FILE), "r", encoding="utf-8") as f:
            data = json.load(f)
            world.load_from_dict(data)
            return True
    except FileNotFoundError:
        return False
