"""
world.py — Manages the dynamic state of the LocalMUD world.

This module tracks rooms, NPCs, and global world flags. It provides
serialization helpers (to_dict / load_from_dict) so the world state can
be saved and restored cleanly by the save system. Static room data
(name, description, exits) should remain in your region modules; only
dynamic state is serialized here.
"""

class World:
    def __init__(self):
        # All rooms keyed by room_id (e.g., "fellmore_cliffs_1_1")
        self.rooms = {}

        # Global world-level flags (story progression, seeds, unlockables)
        self.global_flags = {}

    # ---------------------------------------------------------
    # Serialization
    # ---------------------------------------------------------

    def to_dict(self):
        """Return a JSON-serializable snapshot of the world state."""
        return {
            "rooms": {
                room_id: room.to_dict()
                for room_id, room in self.rooms.items()
            },
            "global_flags": self.global_flags
        }

    def load_from_dict(self, data):
        """Apply saved world data to the current world instance."""
        # Restore global flags
        self.global_flags = data.get("global_flags", {})

        # Restore room state
        saved_rooms = data.get("rooms", {})
        for room_id, room_data in saved_rooms.items():
            if room_id in self.rooms:
                # Update existing room
                self.rooms[room_id].load_from_dict(room_data)
            else:
                # Create a placeholder room if needed
                self.rooms[room_id] = Room(room_id)
                self.rooms[room_id].load_from_dict(room_data)


# ---------------------------------------------------------
# Minimal Room Prototype
# ---------------------------------------------------------

class Room:
    """
    Minimal dynamic room state.

    Static data (name, description, exits) should come from your
    region modules. This class only tracks state that changes during
    gameplay and must be saved.
    """

    def __init__(self, room_id):
        self.room_id = room_id

        # Dynamic state
        self.visited = False
        self.items = []       # items currently in the room
        self.flags = {}       # e.g., {"door_unlocked": True}
        self.npcs = {}        # keyed by npc_id

    def to_dict(self):
        """Return a JSON-serializable snapshot of the room state."""
        return {
            "visited": self.visited,
            "items": self.items,
            "flags": self.flags,
            "npcs": {
                npc_id: npc.to_dict()
                for npc_id, npc in self.npcs.items()
            }
        }

    def load_from_dict(self, data):
        """Apply saved room state."""
        self.visited = data.get("visited", False)
        self.items = data.get("items", [])
        self.flags = data.get("flags", {})

        # Restore NPCs if present
        saved_npcs = data.get("npcs", {})
        for npc_id, npc_data in saved_npcs.items():
            if npc_id in self.npcs:
                self.npcs[npc_id].load_from_dict(npc_data)
            else:
                # Placeholder NPC object (expand later)
                self.npcs[npc_id] = NPC(npc_id)
                self.npcs[npc_id].load_from_dict(npc_data)


# ---------------------------------------------------------
# Minimal NPC Prototype
# ---------------------------------------------------------

class NPC:
    """Simple NPC state container for serialization."""
    def __init__(self, npc_id):
        self.npc_id = npc_id
        self.alive = True
        self.inventory = []
        self.state = {}  # dialogue flags, hostility, etc.

    def to_dict(self):
        return {
            "alive": self.alive,
            "inventory": self.inventory,
            "state": self.state
        }

    def load_from_dict(self, data):
        self.alive = data.get("alive", True)
        self.inventory = data.get("inventory", [])
        self.state = data.get("state", {})
