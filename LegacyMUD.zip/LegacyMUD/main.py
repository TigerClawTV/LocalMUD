import curses
import random

from game.rooms   import rooms
from game.npcs import NPC_DEFS
from game.items   import items
from game.player  import player as initial_player
from game.parser  import handle_command, verify_room_links
from config  import get_motd, VERSION, DEV_NOTE
from ui.ui      import show_title_screen, show_game_over_menu, draw_ui, wrap_text, show_settings_menu 
from world.overworld import load_overworld
from utils.log_manager import cleanup_old_logs, log_room_error
from game.settings import load_settings


from game.character import (
    create_character,
    get_eligible_classes,
    create_character_non_curses
)


cleanup_old_logs()

def return_to_title(stdscr):
    curses.flash()
    stdscr.clear()
    launch(stdscr)  # Restart the game loop


def launch(stdscr, player):
    # Outer loop lets us restart without exiting the program
    while True:
        
        # Load game data
        rooms = load_overworld()
        items = {}  # Load or define items here
        NPC_DEFS = {}  # Load or define NPCs here
        current_motd = get_motd()
        message_log = []
        settings = load_settings()
        player.update(settings)

        # Set starting room
        player["location"] = "chapel_0_0_0"

        """
        # Validate starting room
        if player["location"] not in rooms:
            from utils.log_manager import log_room_error
            print("[ERROR] Starting room not found. Teleporting to fallback.")

        # Log the error with context
        log_room_error(
            current_room="(initial spawn)",
            attempted_coords=player["location"],
            attempted_direction="initial spawn",
            rooms={"(initial spawn)": {"name": "Game Start"}}
        )

        # Fallback to safe room
        player["location"] = "chapel_0_0_0" if "chapel_0_0_0" in rooms else list(rooms.keys())[0]

        """
        # Initialize game state
        game_state = {
            "current_room": player["location"],
            "restart": False,
            "game_over": False
        }
    

        current_motd = get_motd()
        message_log  = []

        # Load settings
        settings = load_settings()

        # Create default player and inject settings
        player = {
            "name":             "",
            "background":       "",
            "hp":               10,
            "max_hp":           10,
            "xp":               0,
            "inventory":        [],
            "location":         "chapel_0_0_0",
            "max_hp_bonus":     False,
            "verbose_travel":   False,
            "screen_reader_mode": False,
            "debug_mode":       False
        }

        player.update(settings)


        # Show title screen and allow settings access
        choice = show_title_screen(stdscr, current_motd, player)

        if choice == "restart":
            continue
        if choice == "quit":
            return
        elif choice == "new":
            # Screen-reader (non-curses) path
            if player.get("screen_reader_mode"):
                print(f"DEBUG: Screen Reader Mode is {'ON' if player.get('screen_reader_mode') else 'OFF'}")
                run_non_curses_mode(player, rooms, items, current_motd, NPC_DEFS)
                return

            # Curses-based character creation (skip intro press‐any‐key)
            curses.curs_set(1)
            stdscr.nodelay(False)
            stdscr.keypad(True)

            # Loop until valid character created
            new_player = None
            while new_player is None:
                print("DEBUG: About to enter create_character()")
                new_player = create_character(stdscr, player)
                print("DEBUG: Returned from create_character()")

            player = new_player

            # Roll intro text
            intro_text = [
                "The chapel is dusty and quiet. Its silence feels safe—but not empty. "
                "The air is thick with memory. Spirits rest here, but their posture is unclear. "
                "You are either being welcomed... or warned.",

                "The country of Eldermere cannot be allowed to fall. Somewhere in these walls lies the answer. "
                "The Oracle lived many lifetimes ago. If anyone still knows the path, it is him.",

                "There must be a way to reach him. The time for answers is now."
            ]

            height, width = stdscr.getmaxyx()
            verify_room_links(rooms)

            for paragraph in intro_text:
                wrapped = wrap_text(paragraph, width - 4)
                message_log.extend(wrapped)
                message_log.append("")

            # Enter main game loop
            main_loop(stdscr, game_state, player, rooms, items, current_motd, message_log, NPC_DEFS)

            if not game_state.get("restart"):
                break


def run_non_curses_mode(player, rooms, items, motd, NPC_DEFS):
    print("DEBUG: Entered run_non_curses_mode()")
    print("Screen Reader Mode enabled. Switching to plain text interface...\n")
    print(f"MOTD: {motd}\n")

    # Character creation
    print("DEBUG: Starting character creation")
    player = create_character_non_curses(player)

    # Intro text
    intro_text = [
        "The chapel is dusty and quiet. Its silence feels safe—but not empty...",
        "The country of Eldermere cannot be allowed to fall...",
        "There must be a way to reach him. The time for answers is now."
    ]
    for paragraph in intro_text:
        print(paragraph)
        input("Press Enter to continue...\n")

    # Initial room description
    current_room = player["location"]
    print(f"You are in {rooms[current_room]['name']}")
    print(rooms[current_room]["look_description"])
    print()

    message_log = []

    # Main input loop
    print("DEBUG: Entering input loop")
    while True:
        command = input("> ").strip().lower()
        if command in ("quit", "exit"):
            print("Thanks for playing!")
            break

        result = handle_command(
            command,
            {"current_room": current_room},
            player,
            rooms,
            items,
            motd,
            message_log,
            NPC_DEFS
        )

        if isinstance(result, list):
            for line in result:
                print(line)
        elif isinstance(result, str):
            if result == "quit":
                print("Thanks for playing LocalMUD!")
                break
            else:
                print(result)

        current_room = player["location"]
        print()


def handle_idle_npc_actions(current_room, NPC_DEFS, message_log):
    present = NPC_DEFS.get(current_room, [])
    for npc in present:
        idle_lines = npc.get("idle_actions", [])
        if idle_lines and random.random() < 0.25:
            message_log.append(random.choice(idle_lines))


def main_loop(stdscr, game_state, player, rooms, items, current_motd, message_log, NPC_DEFS):
    curses.curs_set(1)
    stdscr.nodelay(False)

    while True:
        draw_ui(stdscr, game_state, player, rooms, message_log)

        height, width = stdscr.getmaxyx()
        input_y = height - 2
        stdscr.addstr(input_y, 2, "> ")
        stdscr.refresh()

        # ─── Enhanced Input with Command History ───
        history = game_state.setdefault("command_history", [])
        history_index = -1
        input_buffer = ""

        stdscr.move(input_y, 4)
        stdscr.clrtoeol()
        curses.curs_set(1)
        stdscr.refresh()

        while True:
            key = stdscr.getch()

            if key in (curses.KEY_ENTER, 10, 13):  # Enter
                raw = input_buffer.strip()
                break

            elif key == curses.KEY_UP:
                if history:
                    history_index = max(0, history_index - 1)
                    input_buffer = history[history_index]
                    stdscr.move(input_y, 4)
                    stdscr.clrtoeol()
                    stdscr.addstr(input_y, 4, input_buffer)
                    stdscr.refresh()

            elif key == curses.KEY_DOWN:
                if history:
                    history_index += 1
                    if history_index >= len(history):
                        history_index = -1
                        input_buffer = ""
                    else:
                        input_buffer = history[history_index]
                    stdscr.move(input_y, 4)
                    stdscr.clrtoeol()
                    stdscr.addstr(input_y, 4, input_buffer)
                    stdscr.refresh()

            elif key in (curses.KEY_BACKSPACE, 127, 8):
                input_buffer = input_buffer[:-1]
                stdscr.move(input_y, 4)
                stdscr.clrtoeol()
                stdscr.addstr(input_y, 4, input_buffer)
                stdscr.refresh()

            elif 32 <= key <= 126:  # Printable characters
                input_buffer += chr(key)
                stdscr.addstr(input_y, 4 + len(input_buffer) - 1, chr(key))
                stdscr.refresh()

            else:
                continue  # Ignore other keys

        curses.curs_set(0)
        stdscr.move(input_y, 4)
        stdscr.clrtoeol()
        curses.noecho()

        if raw:
            message_log.append(f"> {raw}")
            if raw not in history:
                history.append(raw)
                if len(history) > 10:
                    history.pop(0)


        # ─── Run parser ───
        result = handle_command(
            raw,
            game_state,
            player,
            rooms,
            items,
            current_motd,
            message_log,
            NPC_DEFS
        )

        # ─── Handle parser output ───
        if isinstance(result, list):
            message_log.extend(result)
        elif isinstance(result, str):
            if result == "quit":
                message_log.append("Thanks for playing LocalMUD!")
                break
            else:
                message_log.append(result)

        message_log.append("")

        # ─── NPC idle actions ───
        handle_idle_npc_actions(game_state["current_room"], NPC_DEFS, message_log)

        # ─── “Return to title” confirmation ───
        if result == "confirm_title":
            stdscr.clear()
            stdscr.addstr(5, 4, "Return to title screen? [Y]es / [N]o")
            stdscr.refresh()
            key = stdscr.getkey().lower()
            if key == "y":
                curses.flash()
                stdscr.clear()
                launch(stdscr, player)
                return
            else:
                message_log.append("Return canceled.")

        # ─── Check for Game Over ───
        if game_state.get("game_over"):
            choice = show_game_over_menu(stdscr, player)
            if choice == "restart":
                game_state["restart"] = True


if __name__ == "__main__":

    # Load settings and initialize player globally
    settings = load_settings()
    player = {
        "name":             "",
        "background":       "",
        "hp":               10,
        "max_hp":           10,
        "xp":               0,
        "inventory":        [],
        "location":         "chapel_0_0_0",
        "max_hp_bonus":     False,
        "verbose_travel":   False,
        "screen_reader_mode": False,
        "debug_mode":       False
    }
    player.update(settings)


    if player.get("screen_reader_mode"):
        run_non_curses_mode(player, rooms, items, get_motd(), NPC_DEFS)
    else:
        curses.wrapper(lambda stdscr: launch(stdscr, player))
